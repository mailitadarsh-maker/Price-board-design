<?php
/**
 * upload.php — Media upload handler for Transgold Markets
 * Place in: /public_html/upload.php  (Hostinger)
 */

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// ── CONFIG ────────────────────────────────────────────────────────────────────
define('UPLOAD_DIR',  __DIR__ . '/media/');   // stored at /public_html/media/
define('UPLOAD_URL',  '/media/');             // public URL path
define('MAX_SLOTS',   3);
define('MAX_SIZE_MB', 50);
define('SLOTS_FILE',  __DIR__ . '/media/slots.json'); // tracks which files occupy which slot

$ALLOWED_TYPES = [
  'image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp',
  'video/mp4', 'video/webm', 'video/ogg', 'video/quicktime'
];
// ─────────────────────────────────────────────────────────────────────────────

// Create media dir if missing
if (!is_dir(UPLOAD_DIR)) {
  mkdir(UPLOAD_DIR, 0755, true);
}

$action = $_POST['action'] ?? $_GET['action'] ?? 'upload';

switch ($action) {

  // ── LIST — return current slots ─────────────────────────────────────────────
  case 'list':
    echo json_encode(['success' => true, 'slots' => loadSlots()]);
    exit;

  // ── REMOVE — clear one slot ─────────────────────────────────────────────────
  case 'remove':
    $slot = (int)($_POST['slot'] ?? -1);
    if ($slot < 0 || $slot >= MAX_SLOTS) {
      echo json_encode(['success' => false, 'error' => 'Invalid slot']);
      exit;
    }
    $slots = loadSlots();
    if ($slots[$slot]) {
      $filepath = UPLOAD_DIR . $slots[$slot]['filename'];
      if (file_exists($filepath)) unlink($filepath);
      $slots[$slot] = null;
    }
    saveSlots($slots);
    echo json_encode(['success' => true, 'slots' => $slots]);
    exit;

  // ── CLEAR ALL ───────────────────────────────────────────────────────────────
  case 'clear':
    $slots = loadSlots();
    foreach ($slots as $s) {
      if ($s) {
        $filepath = UPLOAD_DIR . $s['filename'];
        if (file_exists($filepath)) unlink($filepath);
      }
    }
    $slots = [null, null, null];
    saveSlots($slots);
    echo json_encode(['success' => true, 'slots' => $slots]);
    exit;

  // ── UPLOAD (default) ────────────────────────────────────────────────────────
  default:
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
      http_response_code(405);
      echo json_encode(['success' => false, 'error' => 'POST required']);
      exit;
    }

    $slot = (int)($_POST['slot'] ?? -1);
    if ($slot < 0 || $slot >= MAX_SLOTS) {
      echo json_encode(['success' => false, 'error' => 'slot must be 0–' . (MAX_SLOTS - 1)]);
      exit;
    }

    if (empty($_FILES['file'])) {
      echo json_encode(['success' => false, 'error' => 'No file received']);
      exit;
    }

    $file = $_FILES['file'];

    // PHP upload error check
    if ($file['error'] !== UPLOAD_ERR_OK) {
      echo json_encode(['success' => false, 'error' => 'Upload error code: ' . $file['error']]);
      exit;
    }

    // Size check
    if ($file['size'] > MAX_SIZE_MB * 1024 * 1024) {
      echo json_encode(['success' => false, 'error' => 'File exceeds ' . MAX_SIZE_MB . ' MB limit']);
      exit;
    }

    // MIME type check (use finfo for real MIME, not just extension)
    $finfo    = new finfo(FILEINFO_MIME_TYPE);
    $mimeReal = $finfo->file($file['tmp_name']);
    if (!in_array($mimeReal, $ALLOWED_TYPES)) {
      echo json_encode(['success' => false, 'error' => 'File type not allowed: ' . $mimeReal]);
      exit;
    }

    // Derive safe extension from real MIME
    $extMap = [
      'image/jpeg'  => 'jpg', 'image/jpg'  => 'jpg',
      'image/png'   => 'png', 'image/gif'  => 'gif',
      'image/webp'  => 'webp',
      'video/mp4'   => 'mp4', 'video/webm' => 'webm',
      'video/ogg'   => 'ogv', 'video/quicktime' => 'mov',
    ];
    $ext = $extMap[$mimeReal] ?? 'bin';

    // Remove old file in this slot (if any)
    $slots = loadSlots();
    if ($slots[$slot]) {
      $old = UPLOAD_DIR . $slots[$slot]['filename'];
      if (file_exists($old)) unlink($old);
    }

    // Save with unique name: slot0_<timestamp>.<ext>
    $filename = 'slot' . $slot . '_' . time() . '.' . $ext;
    $dest     = UPLOAD_DIR . $filename;

    if (!move_uploaded_file($file['tmp_name'], $dest)) {
      echo json_encode(['success' => false, 'error' => 'Failed to move uploaded file']);
      exit;
    }

    // Update slot registry
    $isVideo = str_starts_with($mimeReal, 'video/');
    $slots[$slot] = [
      'filename' => $filename,
      'url'      => UPLOAD_URL . $filename,
      'type'     => $isVideo ? 'video' : 'image',
      'name'     => basename($file['name']),
    ];
    saveSlots($slots);

    echo json_encode(['success' => true, 'slot' => $slots[$slot], 'slots' => $slots]);
    exit;
}

// ── HELPERS ───────────────────────────────────────────────────────────────────
function loadSlots(): array {
  if (!file_exists(SLOTS_FILE)) return [null, null, null];
  $data = json_decode(file_get_contents(SLOTS_FILE), true);
  // Ensure exactly 3 entries
  $slots = array_slice(array_pad((array)$data, 3, null), 0, 3);
  return $slots;
}

function saveSlots(array $slots): void {
  file_put_contents(SLOTS_FILE, json_encode($slots, JSON_PRETTY_PRINT));
}
