<?php
header('Content-Type: text/html; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Cache-Control: no-cache, no-store, must-revalidate');

$allowed_host = 'portal.arakkalmarkets.com';
$url = $_GET['url'] ?? '';

if (!$url) { http_response_code(400); echo 'Missing url'; exit; }

$parsed = parse_url($url);
if (!$parsed || ($parsed['host'] ?? '') !== $allowed_host) {
    http_response_code(403); echo 'Host not allowed'; exit;
}

// Use cURL (more reliable on Hostinger than file_get_contents)
$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL            => $url,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT        => 8,
    CURLOPT_CONNECTTIMEOUT => 5,
    CURLOPT_SSL_VERIFYPEER => true,
    CURLOPT_SSL_VERIFYHOST => 2,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_MAXREDIRS      => 3,
    CURLOPT_USERAGENT      => 'Mozilla/5.0 (compatible; TransgoldBoard/1.0)',
    CURLOPT_HTTPHEADER     => [
        'Accept: text/html,application/xhtml+xml',
        'Accept-Language: en-US,en;q=0.9',
    ],
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error    = curl_error($ch);
curl_close($ch);

if ($error) {
    http_response_code(502);
    echo json_encode(['error' => 'cURL error: ' . $error]);
    exit;
}

if ($httpCode !== 200) {
    http_response_code($httpCode ?: 502);
    echo json_encode(['error' => 'Upstream returned ' . $httpCode]);
    exit;
}

echo $response;
